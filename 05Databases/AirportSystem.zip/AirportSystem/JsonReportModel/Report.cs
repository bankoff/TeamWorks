﻿namespace JsonReportModel
{
    public class Report
    {
        public int ReportID { get; set; }

        public string From { get; set; }

        public string To { get; set; }

        public int SellTicketsCount { get; set; }

        public int Year { get; set; }

    }
}
