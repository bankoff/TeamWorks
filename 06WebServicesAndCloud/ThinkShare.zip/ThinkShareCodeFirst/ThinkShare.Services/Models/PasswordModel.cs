﻿namespace ThinkShare.Services.Models
{
    public class PasswordModel
    {
        public string Password { get; set; }
    }
}