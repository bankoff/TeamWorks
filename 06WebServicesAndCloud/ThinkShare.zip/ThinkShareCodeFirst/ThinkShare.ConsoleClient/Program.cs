﻿namespace ThinkShare.ConsoleClient
{
    using ThinkShare.Data;
    using ThinkShare.Model;

    public class Program
    {
        public static void Main()
        {
            //var data = new ThinkShareData();
            //data.Categories.Add(new Category() { PictureUrl = "http://www.telerik-kids.com/images/photos/telerik_kids_academy.jpg?sfvrsn=2", Title = "Kids Academy" });
            //data.SaveChanges();
        }
    }
}
