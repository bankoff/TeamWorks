﻿var users = [];
users[0] = { 'uName': 'test', 'score': 100 };
users[1]={'uName':'pesho', 'score':0};
