//
//  GameOverScene.h
//  SwordfishGame
//
//  Created by admin on 11/6/14.
//  Copyright (c) 2014 admin. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameOverScene : SKScene

- initWithSize:(CGSize)size andScore:(int)score;
@end
