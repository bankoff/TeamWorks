//
//  SharedMainScene.m
//  SwordfishGame
//
//  Created by admin on 11/6/14.
//  Copyright (c) 2014 admin. All rights reserved.
//

#import "SharedMainScene.h"

@interface SharedMainScene()



@end

@implementation SharedMainScene

-(void)setReturnScene:(SKScene *)otherScene{

    _returnScene = otherScene;
}

-(void)didMoveToView:(SKView *)view{
 
}
@end
