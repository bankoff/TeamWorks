﻿namespace Minesweeper.Enums
{
    public enum FieldStatus
    {
        Closed,
        Opened,
        IsAMine
    }
}
