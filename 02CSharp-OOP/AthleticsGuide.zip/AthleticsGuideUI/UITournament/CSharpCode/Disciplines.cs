﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UITournament.CSharpCode
{
    public enum Disciplines
    {
        Sprint100Metres,
        Sprint200Metres,
        Sprint400Metres,
        Hurdles100Metres,
        Hurdles400Metres,
        HighJump,
        LongJump,
        TripleJump,
        PoleVault,
        Heptathlon,
        Decathlon
    }
}
